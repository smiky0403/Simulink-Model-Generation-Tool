 %ini Model creation tool
 %----------------------Ford Motor Company -------------------------
 %--------- Last Modified: Mingqi Shi: mshi15@ford.com -------------
 %--------------- Author: Mingqi Shi: mshi15@ford.com --------------
 
 addpath(genpath(pwd))
 
 
 
 
 